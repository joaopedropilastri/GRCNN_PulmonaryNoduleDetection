# -*- coding: utf-8 -*-
"""
Created on Mon Nov  7 17:55:30 2022

@author: jterr

python tools/train.py configs/GRCNN/mask_rcnn_skgrcnn109_fpn_2x_HCT1T2.py
C:/Users/jterr/Documents/Projeto_IC/GRCNN/GRCNN-main/mmdetection/tools/dist_train.sh configs/GRCNN/mask_rcnn_skgrcnn109_fpn_2x_HCT1T2.py 8
C:/Users/jterr/Documents/Projeto_IC/GRCNN/GRCNN-main/mmdetection/tools/dist_train.sh configs/GRCNN/mask_rcnn_grcnn109_fpn_2x_coco.py 8
"""

_base_ = 'mask_rcnn_skgrcnn109_fpn_2x_coco.py'

# We also need to change the num_classes in head to match the dataset's annotation
model = dict(
    roi_head=dict(
        bbox_head=dict(num_classes=2),
        mask_head=dict(num_classes=2)))

# Modify dataset related settings
dataset_type = 'COCODataset'
classes = ('nodule','non-nodule')
data = dict(
    train=dict(
        img_prefix='/home/mainlab1/IC_Joao_GRCNN/datasetT1T2_train/data/',
        classes=classes,
        ann_file='/home/mainlab1/IC_Joao_GRCNN/datasetT1T2_train/labels.json'),
    val=dict(
        img_prefix='/home/mainlab1/IC_Joao_GRCNN/datasetT1T2_validation/data/',
        classes=classes,
        ann_file='/home/mainlab1/IC_Joao_GRCNN/datasetT1T2_validation/labels.json'),
    test=dict(
        img_prefix='/home/mainlab1/IC_Joao_GRCNN/datasetT1T2_test/data/',
        classes=classes,
        ann_file='/home/mainlab1/IC_Joao_GRCNN/datasetT1T2_test/labels.json'))
